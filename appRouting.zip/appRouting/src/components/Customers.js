import React from 'react'
import GroupsIcon from '@mui/icons-material/Groups';

export default function Customers() {
    return (

        <
        >
        <GroupsIcon/> < p > Customers < /p>  < / >
    )
}