import React from 'react'
import GradingIcon from '@mui/icons-material/Grading';
export default function Proposal() {
    return (

        <
        >
        <GradingIcon/> < p > Proposals < /p>  < / >
    )
}