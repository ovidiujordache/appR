import React from 'react'
import AccountTreeIcon from '@mui/icons-material/AccountTree';
export default function Project() {
    return (

        <
        >
        <AccountTreeIcon/> < p > Projects < /p>  <
        />
    )
}