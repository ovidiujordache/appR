import React from 'react'
import SettingsIcon from '@mui/icons-material/Settings';
import IconButton from '@mui/material/IconButton';
import Button from '@mui/material/Button';
export default function Settings() {
    return (

        <
        >
        <Button onClick={()=>{alert(" projects")}}>
        <SettingsIcon/> < p > Settings < /p>  
        </Button> <
        / >
    )
}