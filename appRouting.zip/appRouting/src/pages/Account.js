import * as React from 'react'
import AccountComponent from '../components/AccountComponent'

export default function Account() {

    return (
        <div>
	<AccountComponent/>
		</div>
    )


}