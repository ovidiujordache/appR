import React from 'react'


const Dash = ({ children }) => {
    return (
        <div><p>Dash</p></div>
    )
}


export default Dash