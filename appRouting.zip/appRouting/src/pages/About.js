import React from 'react'
import About from '../components/About'


export default function HomePage() {

    return (

        <div>
		<About/>
		</div>
    )


}