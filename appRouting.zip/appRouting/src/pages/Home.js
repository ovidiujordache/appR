import React from 'react'
import HomeComponent from '../components/HomeComponent'


export default function Home() {

    return (

        <div>
		<HomeComponent/>
		</div>
    )


}